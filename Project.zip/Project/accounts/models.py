from django.db import models
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError
import uuid
from django.utils import timezone


class Users(models.Model):
    id = models.AutoField(primary_key=True)
    Firstname = models.CharField(max_length=50, null=False)
    Lastname = models.CharField(max_length=50, null=False)
    Email = models.TextField(max_length=20, null=False,
                             unique=True, blank=False, default='dasdasd')
    Password = models.CharField(max_length=50, null=False, default='12345678')
    RepeatPassword = models.CharField(
        max_length=50, null=False, default='12345678')
    mobile_phone = models.CharField(max_length=11, unique=True, validators=[
                                    RegexValidator(r'^01[0125][0-9]{8}$', 'Invalid mobile phone number.')], default='0123456789')
    image = models.ImageField(
        upload_to='images/%y/%m/%d', null=True, blank=True)

    def __str__(self):
        return self.Firstname


class Activation(models.Model):
    user = models.OneToOneField(Users, on_delete=models.CASCADE)
    token = models.UUIDField(default=uuid.uuid4, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    def is_expired(self):
        return self.expires_at <= timezone.now()

    def __str__(self):
        return f"Activation for {self.user.Firstname}"
# class Tag(models.Model):
#    title= models.CharField(max_length=50, null=False ,default='unknown')
#    def _str_(self):
#         return self.title
# class Category(models.Model):
#     title= models.CharField(max_length=50, null=False ,default='unknown')
#     def _str_(self):
#       return self.title
# class Project(models.Model):
#     title= models.CharField(max_length=50, null=False)
#     details=models.TextField()
#     Project_tag = models.ManyToManyField(Tag)
#     Project_Cat = models.ForeignKey(Category, on_delete=models.CASCADE)
class Category(models.Model):
    name = models.CharField(max_length=50, null=False ,default='unknown')
    def __str__(self):
        return self.name
class Tag(models.Model):
    name = models.CharField(max_length=50, null=False ,default='unknown')
    def __str__(self):
        return self.name

class Picture(models.Model):
    image = models.ImageField(upload_to='campaign_images/')

class Campaign(models.Model):
    title = models.CharField(max_length=255)
    details = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    pictures = models.ManyToManyField(Picture)
    total_target = models.PositiveIntegerField()
    tags = models.ManyToManyField(Tag)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()

    def __str__(self):
        return self.title
class Test(models.Model):
    title = models.CharField(max_length=255)
    def __str__(self):
        return self.title