from django.contrib import admin
from .models import Users, Activation , Tag , Category  , Campaign , Picture 
# Register your models here.

admin.site.register(Users)
admin.site.register(Activation)
admin.site.register(Tag)
admin.site.register(Category)
admin.site.register(Campaign)
admin.site.register(Picture)