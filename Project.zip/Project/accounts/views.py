from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from .models import Users, Activation
from django.contrib import messages
from django.contrib.auth import authenticate, login
from .Forms import Register
from datetime import timedelta
from django.shortcuts import render, redirect, reverse
from django.contrib import messages
from django.core.mail import send_mail
from .models import Activation
from django.utils import timezone
import time


def AddUser(request):
    if request.method == 'POST':
        user = Register(request.POST, request.FILES)
        if user.is_valid():
            my_user = user.save(commit=False)
            my_user.image = request.FILES['image']
            my_user.save()
            activation = Activation.objects.create(
                user=my_user, expires_at=timezone.now() + timedelta(hours=24))
            activation_url = request.build_absolute_uri(
                reverse('activate', args=[str(activation.token)]))
            send_mail(
                'Activate your account',
                f'Please click the link below to activate your account:\n{activation_url}',
                'noreply@example.com',
                [my_user.Email],
                fail_silently=False,
            )

            return render(request, 'accounts/Registeration_done.html', {'user': my_user.Firstname, 'email': my_user.Email})
        else:
            user = Register()
            print(user.errors)
    return render(request, "accounts/Signup.html")


def activate(request, token):
    activation = get_object_or_404(Activation, token=token)

    if activation.is_expired():
        activation.delete()
        return HttpResponse("Activation link has expired")

    user = activation.user
    user.is_active = True
    user.save()
    activation.delete()
    return render(request, 'accounts/Activated.html', {'user': user.Firstname, 'email': user.Email})

    time.sleep(3)

    return redirect('Login')


# def Login(request):
#     if request.method == 'POST':
#         useremail = request.POST['email']
#         password = request.POST['password']
#         user = Users.objects.filter(Email=useremail).first()
#         if user is not None:
#             user_login = authenticate(
#                 request, Email=useremail, Password=password)
#             if user_login is not None:
#                 login(request, user_login)
#                 return HttpResponse("welcome")
#             else:
#                 return HttpResponse("Invalid Credentials")
#         elif user is None or not user.Password == password:
#             error_msg = "Invalid email or password Please try again"
#             return render(request, 'accounts/Login.html', {'error_msg': error_msg})

#     else:
#         return render(request, 'accounts/Login.html')
from accounts.models import Campaign , Category , Tag
from django.shortcuts import render, redirect, reverse
def slide_project(request):
    Project=Campaign.objects.all()
    print(Project)
    return render(request , 'hompage/home.html',{'projects:':Project } ) 