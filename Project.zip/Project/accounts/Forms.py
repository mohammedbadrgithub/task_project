from .models import Users
from django import forms


class Register(forms.ModelForm):
    class Meta:
        model = Users
        fields = "__all__"
