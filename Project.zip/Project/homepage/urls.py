from django.urls import path
from homepage.views import slide_project , list_category ,search_bar
# from django.urls import url


urlpatterns = [

    path('' ,slide_project , name='home' ),
    path('category/<int:id>' , list_category , name='category' ),
    path('search', search_bar , name='search'),   
    

]