from django.shortcuts import render
from accounts.models import Campaign , Category , Tag
from django.shortcuts import render, redirect
from django.db.models import Q
from django.http import HttpResponse
def slide_project(request):
    dataorder =Campaign.objects.order_by('-total_target')[:5]
    lastprojects=Campaign.objects.all().order_by('-id')[:5]
    allcategory = Category.objects.all()
    for p in dataorder :
        print(p.tags)
    return render(request , 'hompage/home.html',{'projectAll':lastprojects , 'ordering':dataorder , 'allcategory':allcategory}  ) 

def list_category(request , id):
    projects_Cat = Campaign.objects.filter(category = id)
    print(projects_Cat)
    return render(request , 'hompage/catproject.html',{'projectAll':projects_Cat }  ) 

def search_bar(request):
    if request.method == 'GET':
        search = request.GET.get('query')   
        print(search)
        if search is not None:
            # lookups= Q(title__icontains=search) | Q(content__icontains=search)
            projects = Campaign.objects.filter(title__icontains=search)
            projects = Campaign.objects.filter(title__icontains=search)
        return render(request , 'hompage/search.html' ,{'answer':projects}  )
    # else :
    #      return HttpResponse('none')
